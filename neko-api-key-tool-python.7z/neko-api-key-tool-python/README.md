# Neko API Key Tool - Python版本

<div align="center">

**NewAPI 令牌查询工具 - 命令行版本**

一个简洁高效的 NewAPI 令牌查询与管理命令行工具，支持多服务器聚合查询、余额监控、调用详情统计等功能。

🐍 Python | 🖥️ CLI | 🚀 高性能 | 📊 数据导出

</div>

## ⚠️ 重要说明

> **该项目需配合 NewAPI 才能正常使用：[https://github.com/Calcium-Ion/new-api](https://github.com/Calcium-Ion/new-api)**

## ✨ 功能特性

### 🎯 核心功能
- **令牌信息查询** - 快速查询令牌余额、已用额度、有效期等信息
- **调用详情统计** - 详细展示 API 调用记录，包括模型、用时、Token 消耗等
- **多种令牌格式支持** - 兼容 `sk-xxx`、`sess-xxx` 及其他 NewAPI 令牌格式
- **智能错误处理** - 完善的错误处理，友好的错误信息提示

### 🚀 高级特性
- **多服务器支持** - 可同时管理多个 NewAPI 服务器实例
- **命令行配置** - 支持环境变量和命令行参数配置服务器地址
- **数据导出** - 支持将调用记录导出为 CSV 文件
- **彩色输出** - 使用 Rich 库提供美观的命令行界面

### 🎨 用户体验
- **交互式界面** - 支持交互式服务器选择和参数输入
- **进度指示** - 查询过程中显示进度动画
- **格式化显示** - 表格化显示数据，易于阅读
- **统计摘要** - 自动计算总费用和 Token 使用量

## 🛠️ 技术栈

- **语言**: Python 3.7+
- **HTTP 客户端**: Requests
- **CLI 框架**: Click
- **终端美化**: Rich
- **数据处理**: Python 标准库

## 📦 安装部署

### 方案一：直接运行（推荐）

1. **克隆项目**
```bash
git clone https://github.com/your-repo/neko-api-key-tool-python.git
cd neko-api-key-tool-python
```

2. **安装依赖**
```bash
pip install -r requirements.txt
```

3. **配置环境变量（可选）**
```bash
# 单个服务器配置
export NEKO_BASE_URL="https://your-newapi-domain.com"

# 多服务器配置（JSON 格式）
export NEKO_BASE_URL='{"主服务器": "https://api1.example.com", "备用服务器": "https://api2.example.com"}'

# 功能开关
export NEKO_SHOW_BALANCE=true
export NEKO_SHOW_DETAIL=true
```

4. **开始使用**
```bash
python cli.py --help
```

### 方案二：系统全局安装

```bash
# 创建可执行文件链接
chmod +x cli.py
sudo ln -s $(pwd)/cli.py /usr/local/bin/neko-api

# 现在可以全局使用
neko-api --help
```

## 🎯 使用指南

### 基本查询

```bash
# 查询令牌信息
python cli.py query --token sk-your-token-here

# 指定服务器查询
python cli.py query --token sk-your-token-here --server "主服务器"

# 导出调用记录
python cli.py query --token sk-your-token-here --export logs.csv

# 只显示余额信息（跳过日志）
python cli.py query --token sk-your-token-here --no-logs

# 只显示日志（跳过余额）
python cli.py query --token sk-your-token-here --no-balance
```

### 服务器管理

```bash
# 查看已配置的服务器
python cli.py servers

# 添加自定义服务器
python cli.py add-server --name "测试服务器" --url "https://test-api.example.com"
```

### 交互式使用

如果没有提供必要参数，工具会进入交互模式：

```bash
# 会提示输入 token
python cli.py query

# 会提示选择服务器（如果配置了多个）
python cli.py query --token sk-your-token-here
```

### 环境变量配置

创建 `.env` 文件或设置环境变量：

```bash
# 基础配置
NEKO_BASE_URL=https://your-newapi-domain.com
NEKO_SHOW_BALANCE=true
NEKO_SHOW_DETAIL=true

# 多服务器配置
NEKO_BASE_URL={"主服务器": "https://api1.example.com", "备用服务器": "https://api2.example.com"}
```

## 📋 命令参考

### 主要命令

| 命令 | 描述 |
|------|------|
| `query` | 查询令牌信息和使用详情 |
| `servers` | 列出已配置的服务器 |
| `add-server` | 添加自定义服务器 |

### query 命令选项

| 选项 | 简写 | 描述 |
|------|------|------|
| `--token` | `-t` | API 令牌 |
| `--server` | `-s` | 服务器名称 |
| `--export` | `-e` | 导出 CSV 文件路径 |
| `--no-balance` | | 跳过余额信息 |
| `--no-logs` | | 跳过调用日志 |

### 使用示例

```bash
# 完整查询并导出
python cli.py query -t sk-xxx -s "主服务器" -e "./exports/logs_$(date +%Y%m%d).csv"

# 快速余额查询
python cli.py query -t sk-xxx --no-logs

# 批量查询（可以写脚本）
for token in sk-token1 sk-token2 sk-token3; do
    python cli.py query -t $token --no-logs
done
```

## 🎨 输出示例

### 令牌查询结果

```
🔍 Querying token information...

┌─────────── 📊 Query Results ───────────┐
│ 🔑 Token: sk-1234567890abcdef...        │
│ 🌐 Server: https://api.example.com     │
└─────────────────────────────────────────┘

                💰 Balance Information                
┏━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃ Property     ┃ Value                        ┃
┡━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┩
│ Total Credit │ $100.00                      │
│ Used Credit  │ $23.45                       │
│ Remaining    │ $76.55                       │
│ Expires      │ 2024-12-31 23:59:59         │
└──────────────┴──────────────────────────────┘

              📋 API Call Logs (45 entries)             
┏━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━┳━━━━━━━━━━━┳━━━━━━━━━┳━━━━━━━━━━┳━━━━━━━━━━┓
┃ Time              ┃ Model     ┃ Tokens    ┃ Cost    ┃ Duration ┃ Type     ┃
┡━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━╇━━━━━━━━━━━╇━━━━━━━━━╇━━━━━━━━━━╇━━━━━━━━━━┩
│ 2024-01-15 14:30  │ gpt-4     │ 150+300=450 │ $0.0270 │ 2.34s    │ Standard │
│ 2024-01-15 14:25  │ gpt-3.5   │ 80+120=200  │ $0.0008 │ 1.12s    │ Stream   │
└───────────────────┴───────────┴───────────┴─────────┴──────────┴──────────┘

📊 Summary: Total cost: $23.4500, Total tokens: 128,450
```

## 🔧 开发指南

### 项目结构

```
neko-api-key-tool-python/
├── cli.py              # 主命令行入口
├── api_client.py       # NewAPI 客户端
├── config.py           # 配置管理
├── utils.py            # 工具函数
├── requirements.txt    # 依赖列表
└── README.md          # 说明文档
```

### 核心模块说明

**cli.py** - 命令行界面
- Click 框架构建的 CLI
- Rich 库美化输出
- 交互式用户体验

**api_client.py** - API 客户端
- NewAPI 端点封装
- 错误处理和重试
- 数据格式化

**config.py** - 配置管理
- 环境变量解析
- 多服务器配置
- 动态服务器添加

**utils.py** - 工具函数
- 时间格式化
- 数据处理
- 通用辅助函数

## 🐛 故障排除

### 常见问题

**Q: ModuleNotFoundError: No module named 'xxx'**
```bash
# 重新安装依赖
pip install -r requirements.txt
```

**Q: 查询失败，提示网络错误**
```bash
# 检查服务器配置
python cli.py servers

# 测试网络连接
curl -I https://your-newapi-domain.com
```

**Q: 令牌格式不支持**
- 确认令牌来源于兼容的 NewAPI 实例
- 检查令牌是否完整复制（包含 sk- 或 sess- 前缀）

**Q: 权限错误**
```bash
# 检查令牌权限
# 确保令牌有访问 billing 和 log 端点的权限
```

### 调试模式

```bash
# 查看详细错误信息
python -v cli.py query --token sk-xxx

# 查看网络请求详情
export PYTHONHTTPSVERIFY=0  # 仅调试用，不推荐生产使用
```

## 🔒 安全说明

- **客户端应用**: 所有数据处理均在本地进行，不经过第三方服务器
- **令牌安全**: 令牌仅用于查询，不会被存储或上传
- **网络安全**: 建议在生产环境中使用 HTTPS 连接

## 🤝 贡献指南

欢迎提交 Issue 和 Pull Request！

1. Fork 项目
2. 创建功能分支 (`git checkout -b feature/AmazingFeature`)
3. 提交更改 (`git commit -m 'Add some AmazingFeature'`)
4. 推送到分支 (`git push origin feature/AmazingFeature`)
5. 创建 Pull Request

## 📄 开源协议

本项目基于 MIT 协议开源。

## 🙏 致谢

- [NewAPI](https://github.com/Calcium-Ion/new-api) - 核心 API 服务
- [Click](https://click.palletsprojects.com/) - CLI 框架
- [Rich](https://rich.readthedocs.io/) - 终端美化库
- [Requests](https://docs.python-requests.org/) - HTTP 客户端

---

<div align="center">

**如果这个项目对你有帮助，请给个 ⭐ Star 支持一下！**

Made with ❤️ by Python Community

</div>