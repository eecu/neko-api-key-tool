import json
from datetime import datetime
from typing import List, Dict, Tuple, Any

def format_datetime(timestamp: Any) -> str:
    """Format timestamp to readable datetime string"""
    if not timestamp:
        return "Unknown"
    
    try:
        # Handle both unix timestamp and datetime string
        if isinstance(timestamp, (int, float)):
            dt = datetime.fromtimestamp(timestamp)
        elif isinstance(timestamp, str):
            # Try parsing common datetime formats
            for fmt in ['%Y-%m-%dT%H:%M:%S.%fZ', '%Y-%m-%dT%H:%M:%SZ', '%Y-%m-%d %H:%M:%S']:
                try:
                    dt = datetime.strptime(timestamp, fmt)
                    break
                except ValueError:
                    continue
            else:
                return timestamp  # Return as-is if parsing fails
        else:
            return str(timestamp)
        
        return dt.strftime('%Y-%m-%d %H:%M:%S')
    except (ValueError, OSError):
        return str(timestamp)

def format_tokens(prompt_tokens: int, completion_tokens: int) -> str:
    """Format token count display"""
    total = prompt_tokens + completion_tokens
    return f"{prompt_tokens}+{completion_tokens}={total}"

def format_quota(quota: Any) -> str:
    """Format quota/cost value"""
    if not quota:
        return "$0.00"
    
    try:
        if isinstance(quota, str):
            quota = float(quota)
        return f"${quota:.4f}"
    except (ValueError, TypeError):
        return str(quota)

def calculate_total_usage(logs: List[Dict[str, Any]]) -> Tuple[float, int]:
    """Calculate total cost and token usage from logs"""
    total_cost = 0.0
    total_tokens = 0
    
    for log in logs:
        # Add quota/cost
        quota = log.get('quota', 0)
        if isinstance(quota, (int, float)):
            total_cost += quota
        elif isinstance(quota, str):
            try:
                total_cost += float(quota)
            except ValueError:
                pass
        
        # Add tokens
        prompt_tokens = log.get('prompt_tokens', 0) or 0
        completion_tokens = log.get('completion_tokens', 0) or 0
        
        if isinstance(prompt_tokens, (int, float)):
            total_tokens += int(prompt_tokens)
        if isinstance(completion_tokens, (int, float)):
            total_tokens += int(completion_tokens)
    
    return total_cost, total_tokens

def parse_json_safe(text: str, default: Any = None) -> Any:
    """Safely parse JSON string, return default on error"""
    try:
        return json.loads(text)
    except (json.JSONDecodeError, TypeError):
        return default

def truncate_string(text: str, max_length: int = 50) -> str:
    """Truncate string with ellipsis if too long"""
    if not text or len(text) <= max_length:
        return text
    return text[:max_length-3] + "..."

def validate_url(url: str) -> bool:
    """Basic URL validation"""
    if not url or not isinstance(url, str):
        return False
    
    url = url.strip()
    return url.startswith(('http://', 'https://')) and len(url) > 10

def safe_get_nested(data: Dict, keys: List[str], default: Any = None) -> Any:
    """Safely get nested dictionary value"""
    try:
        result = data
        for key in keys:
            result = result[key]
        return result
    except (KeyError, TypeError, AttributeError):
        return default

def format_file_size(size_bytes: int) -> str:
    """Format file size in human readable format"""
    if size_bytes == 0:
        return "0 B"
    
    size_names = ["B", "KB", "MB", "GB", "TB"]
    i = 0
    while size_bytes >= 1024 and i < len(size_names) - 1:
        size_bytes /= 1024.0
        i += 1
    
    return f"{size_bytes:.1f} {size_names[i]}"