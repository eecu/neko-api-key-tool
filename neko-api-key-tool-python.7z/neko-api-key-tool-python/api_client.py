import requests
import json
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple, Any
from urllib.parse import urljoin

class NewAPIClient:
    """Client for interacting with NewAPI endpoints"""
    
    def __init__(self, base_url: str, timeout: int = 10):
        self.base_url = base_url.rstrip('/')
        self.timeout = timeout
        self.session = requests.Session()
        
        # Set up request headers
        self.session.headers.update({
            'User-Agent': 'Neko-API-Key-Tool-Python/1.0',
            'Content-Type': 'application/json'
        })
    
    def _make_request(self, method: str, endpoint: str, headers: Dict = None, **kwargs) -> requests.Response:
        """Make HTTP request with error handling"""
        url = urljoin(self.base_url + '/', endpoint.lstrip('/'))
        
        request_headers = self.session.headers.copy()
        if headers:
            request_headers.update(headers)
        
        try:
            response = self.session.request(
                method=method,
                url=url,
                headers=request_headers,
                timeout=self.timeout,
                **kwargs
            )
            return response
        except requests.RequestException as e:
            raise ConnectionError(f"Request failed: {str(e)}")
    
    def get_subscription_info(self, api_key: str) -> Dict[str, Any]:
        """Get token subscription/balance information"""
        headers = {'Authorization': f'Bearer {api_key}'}
        
        try:
            response = self._make_request('GET', '/v1/dashboard/billing/subscription', headers=headers)
            
            if response.status_code == 200:
                return response.json()
            elif response.status_code == 401:
                raise ValueError("Invalid API key or unauthorized access")
            elif response.status_code == 404:
                raise ValueError("Endpoint not found - check if this is a valid NewAPI instance")
            else:
                raise RuntimeError(f"API request failed with status {response.status_code}: {response.text}")
                
        except json.JSONDecodeError:
            raise ValueError("Invalid response format from server")
    
    def get_usage_info(self, api_key: str, days: int = 30) -> Dict[str, Any]:
        """Get token usage information for specified date range"""
        headers = {'Authorization': f'Bearer {api_key}'}
        
        # Calculate date range
        end_date = datetime.now()
        start_date = end_date - timedelta(days=days)
        
        params = {
            'start_date': start_date.strftime('%Y-%m-%d'),
            'end_date': end_date.strftime('%Y-%m-%d')
        }
        
        try:
            response = self._make_request(
                'GET', 
                '/v1/dashboard/billing/usage', 
                headers=headers, 
                params=params
            )
            
            if response.status_code == 200:
                return response.json()
            elif response.status_code == 401:
                raise ValueError("Invalid API key or unauthorized access")
            else:
                raise RuntimeError(f"Usage API request failed with status {response.status_code}: {response.text}")
                
        except json.JSONDecodeError:
            raise ValueError("Invalid response format from server")
    
    def get_token_logs(self, api_key: str) -> List[Dict[str, Any]]:
        """Get detailed API call logs for the token"""
        params = {'key': api_key}
        
        try:
            response = self._make_request('GET', '/api/log/token', params=params)
            
            if response.status_code == 200:
                data = response.json()
                # The API returns {"data": [...]} format
                if isinstance(data, dict) and 'data' in data:
                    return data['data']
                elif isinstance(data, list):
                    return data
                else:
                    return []
            elif response.status_code == 401:
                raise ValueError("Invalid API key or unauthorized access")
            elif response.status_code == 404:
                raise ValueError("Logs endpoint not found - check if this is a valid NewAPI instance")
            else:
                raise RuntimeError(f"Logs API request failed with status {response.status_code}: {response.text}")
                
        except json.JSONDecodeError:
            raise ValueError("Invalid response format from server")
    
    def get_complete_token_info(self, api_key: str) -> Dict[str, Any]:
        """Get complete token information including balance, usage, and logs"""
        result = {
            'api_key': api_key,
            'server_url': self.base_url,
            'subscription': None,
            'usage': None,
            'logs': [],
            'errors': []
        }
        
        # Get subscription info
        try:
            result['subscription'] = self.get_subscription_info(api_key)
        except Exception as e:
            result['errors'].append(f"Subscription info error: {str(e)}")
        
        # Get usage info
        try:
            result['usage'] = self.get_usage_info(api_key)
        except Exception as e:
            result['errors'].append(f"Usage info error: {str(e)}")
        
        # Get logs
        try:
            result['logs'] = self.get_token_logs(api_key)
        except Exception as e:
            result['errors'].append(f"Logs error: {str(e)}")
        
        return result
    
    def validate_token_format(self, api_key: str) -> bool:
        """Validate if the token has a recognized format"""
        if not api_key or not isinstance(api_key, str):
            return False
        
        # Common NewAPI token formats
        valid_prefixes = ['sk-', 'sess-']
        return any(api_key.startswith(prefix) for prefix in valid_prefixes) and len(api_key) > 10