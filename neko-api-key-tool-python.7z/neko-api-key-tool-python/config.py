import os
import json
from pathlib import Path
from typing import Dict, Optional, Union

class Config:
    """Configuration manager for the Neko API Key Tool"""
    
    def __init__(self):
        self._load_env_file()
        self.show_balance = self._get_bool_env('NEKO_SHOW_BALANCE', True)
        self.show_detail = self._get_bool_env('NEKO_SHOW_DETAIL', True)
        self.base_urls = self._get_base_urls()
    
    def _load_env_file(self):
        """Load .env file if it exists"""
        env_file = Path('.env')
        if env_file.exists():
            with open(env_file, 'r', encoding='utf-8') as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith('#'):
                        if '=' in line:
                            key, value = line.split('=', 1)
                            os.environ.setdefault(key.strip(), value.strip())
    
    def _get_bool_env(self, key: str, default: bool) -> bool:
        """Get boolean environment variable"""
        value = os.getenv(key, str(default)).lower()
        return value in ('true', '1', 'yes', 'on')
    
    def _get_base_urls(self) -> Dict[str, str]:
        """Get base URLs configuration from environment"""
        base_url_env = os.getenv('NEKO_BASE_URL', '')
        
        if not base_url_env:
            return {}
        
        # Try to parse as JSON for multiple servers
        try:
            urls = json.loads(base_url_env)
            if isinstance(urls, dict):
                return urls
        except json.JSONDecodeError:
            pass
        
        # Single URL configuration
        return {"默认服务器": base_url_env}
    
    def add_custom_url(self, name: str, url: str):
        """Add a custom server URL"""
        self.base_urls[name] = url.rstrip('/')
    
    def get_server_names(self):
        """Get list of configured server names"""
        return list(self.base_urls.keys())
    
    def get_server_url(self, name: str) -> Optional[str]:
        """Get URL for a specific server"""
        return self.base_urls.get(name)

# Global configuration instance
config = Config()