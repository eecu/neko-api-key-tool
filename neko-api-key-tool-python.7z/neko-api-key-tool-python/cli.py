#!/usr/bin/env python3
# python cli.py query --token 
import click
import csv
import json
import sys
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Any, Optional

from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.prompt import Prompt, Confirm
from rich import print as rprint

from api_client import NewAPIClient
from config import config
from utils import format_datetime, format_tokens, format_quota, calculate_total_usage

console = Console()

@click.group()
@click.version_option(version="1.0.0", prog_name="Neko API Key Tool")
def cli():
    """
    🐱 Neko API Key Tool - Python版本
    
    NewAPI 令牌查询与管理工具，支持多服务器聚合查询、余额监控、调用详情统计等功能。
    """
    pass

@cli.command()
@click.option('--token', '-t', prompt='API Token', help='Your NewAPI token (sk-xxx or sess-xxx format)')
@click.option('--server', '-s', help='Server name to query (use --list-servers to see available servers)')
@click.option('--export', '-e', help='Export logs to CSV file')
@click.option('--no-balance', is_flag=True, help='Skip balance information')
@click.option('--no-logs', is_flag=True, help='Skip call logs')
def query(token: str, server: Optional[str], export: Optional[str], no_balance: bool, no_logs: bool):
    """Query token information and usage details"""
    
    # Validate token format
    if not NewAPIClient("").validate_token_format(token):
        console.print("[red]❌ Invalid token format. Expected formats: sk-xxx, sess-xxx[/red]")
        sys.exit(1)
    
    # Get server URL
    server_url = _get_server_url(server)
    if not server_url:
        return
    
    # Create API client
    client = NewAPIClient(server_url)
    
    # Query token information with progress indicator
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console
    ) as progress:
        task = progress.add_task("🔍 Querying token information...", total=None)
        
        try:
            result = client.get_complete_token_info(token)
        except Exception as e:
            console.print(f"[red]❌ Query failed: {str(e)}[/red]")
            sys.exit(1)
    
    # Display results
    _display_results(result, not no_balance, not no_logs)
    
    # Export logs if requested
    if export and result.get('logs'):
        _export_logs_to_csv(result['logs'], export)

@cli.command()
def servers():
    """List configured servers"""
    server_names = config.get_server_names()
    
    if not server_names:
        console.print("[yellow]⚠️  No servers configured. Set NEKO_BASE_URL environment variable.[/yellow]")
        console.print("\nExample:")
        console.print("  export NEKO_BASE_URL='https://your-newapi-domain.com'")
        console.print('  export NEKO_BASE_URL=\'{"主服务器": "https://api1.example.com", "备用服务器": "https://api2.example.com"}\'')
        return
    
    table = Table(title="📋 Configured Servers")
    table.add_column("Name", style="cyan")
    table.add_column("URL", style="green")
    
    for name in server_names:
        url = config.get_server_url(name)
        table.add_row(name, url)
    
    console.print(table)

@cli.command()
@click.option('--name', '-n', prompt='Server name', help='Name for the server')
@click.option('--url', '-u', prompt='Server URL', help='NewAPI server URL')
def add_server(name: str, url: str):
    """Add a custom server configuration"""
    config.add_custom_url(name, url)
    console.print(f"[green]✅ Added server '{name}': {url}[/green]")

def _get_server_url(server_name: Optional[str]) -> Optional[str]:
    """Get server URL by name or prompt user to select"""
    server_names = config.get_server_names()
    
    if not server_names:
        console.print("[red]❌ No servers configured. Use 'add-server' command or set NEKO_BASE_URL environment variable.[/red]")
        return None
    
    if server_name:
        url = config.get_server_url(server_name)
        if not url:
            console.print(f"[red]❌ Server '{server_name}' not found. Use --list-servers to see available servers.[/red]")
            return None
        return url
    
    if len(server_names) == 1:
        return config.get_server_url(server_names[0])
    
    # Multiple servers - prompt user to choose
    console.print("📋 Available servers:")
    for i, name in enumerate(server_names, 1):
        console.print(f"  {i}. {name}")
    
    while True:
        try:
            choice = Prompt.ask("Select server", choices=[str(i) for i in range(1, len(server_names) + 1)])
            selected_name = server_names[int(choice) - 1]
            return config.get_server_url(selected_name)
        except (ValueError, IndexError):
            console.print("[red]Invalid choice. Please try again.[/red]")

def _display_results(result: Dict[str, Any], show_balance: bool, show_logs: bool):
    """Display query results in a formatted way"""
    
    # Display errors if any
    if result.get('errors'):
        for error in result['errors']:
            console.print(f"[yellow]⚠️  {error}[/yellow]")
        console.print()
    
    # Token info header
    console.print(Panel.fit(
        f"🔑 Token: {result['api_key'][:20]}...\n🌐 Server: {result['server_url']}",
        title="📊 Query Results"
    ))
    
    # Balance/Subscription information
    if show_balance and result.get('subscription'):
        _display_balance_info(result['subscription'], result.get('usage'))
    
    # Call logs
    if show_logs and result.get('logs'):
        _display_logs_table(result['logs'])

def _display_balance_info(subscription: Dict, usage: Dict):
    """Display balance and usage information"""
    table = Table(title="💰 Balance Information")
    table.add_column("Property", style="cyan")
    table.add_column("Value", style="green")
    
    if 'hard_limit_usd' in subscription:
        table.add_row("Total Credit", f"${subscription['hard_limit_usd']:.2f}")
    
    if usage and 'total_usage' in usage:
        table.add_row("Used Credit", f"${usage['total_usage']:.2f}")
        
        if 'hard_limit_usd' in subscription:
            remaining = subscription['hard_limit_usd'] - usage['total_usage']
            table.add_row("Remaining", f"${remaining:.2f}")
    
    if 'access_until' in subscription:
        expiry = datetime.fromtimestamp(subscription['access_until'])
        table.add_row("Expires", expiry.strftime("%Y-%m-%d %H:%M:%S"))
    
    console.print(table)
    console.print()

def _display_logs_table(logs: List[Dict]):
    """Display API call logs in a table"""
    if not logs:
        console.print("[yellow]📝 No API call logs found[/yellow]")
        return
    
    table = Table(title=f"📋 API Call Logs ({len(logs)} entries)")
    table.add_column("Time", style="dim")
    table.add_column("Model", style="cyan")
    table.add_column("Tokens", style="yellow", justify="right")
    table.add_column("Cost", style="green", justify="right")
    table.add_column("Duration", style="blue", justify="right")
    table.add_column("Type", style="magenta")
    
    # Sort logs by creation time (most recent first)
    sorted_logs = sorted(logs, key=lambda x: x.get('created_at', 0), reverse=True)
    
    # Show only first 20 logs to avoid overwhelming output
    display_logs = sorted_logs[:20]
    
    for log in display_logs:
        time_str = format_datetime(log.get('created_at'))
        model = log.get('model_name', 'Unknown')
        
        prompt_tokens = log.get('prompt_tokens', 0)
        completion_tokens = log.get('completion_tokens', 0)
        tokens_str = format_tokens(prompt_tokens, completion_tokens)
        
        cost = format_quota(log.get('quota', 0))
        duration = f"{log.get('use_time', 0):.2f}s"
        request_type = "Stream" if log.get('is_stream') else "Standard"
        
        table.add_row(time_str, model, tokens_str, cost, duration, request_type)
    
    console.print(table)
    
    if len(logs) > 20:
        console.print(f"[dim]... and {len(logs) - 20} more entries (use --export to save all logs)[/dim]")
    
    # Summary statistics
    total_cost, total_tokens = calculate_total_usage(logs)
    console.print(f"\n📊 [bold]Summary:[/bold] Total cost: {format_quota(total_cost)}, Total tokens: {total_tokens:,}")
    console.print()

def _export_logs_to_csv(logs: List[Dict], filename: str):
    """Export logs to CSV file"""
    try:
        Path(filename).parent.mkdir(parents=True, exist_ok=True)
        
        with open(filename, 'w', newline='', encoding='utf-8') as csvfile:
            if not logs:
                csvfile.write("No data to export\n")
                console.print(f"[yellow]⚠️  No logs to export to {filename}[/yellow]")
                return
            
            # CSV headers
            fieldnames = [
                'created_at', 'formatted_time', 'token_name', 'model_name',
                'prompt_tokens', 'completion_tokens', 'total_tokens',
                'quota', 'use_time', 'is_stream', 'content'
            ]
            
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writeheader()
            
            for log in logs:
                row = {}
                for field in fieldnames:
                    if field == 'formatted_time':
                        row[field] = format_datetime(log.get('created_at'))
                    elif field == 'total_tokens':
                        row[field] = (log.get('prompt_tokens', 0) + 
                                    log.get('completion_tokens', 0))
                    else:
                        row[field] = log.get(field, '')
                
                writer.writerow(row)
        
        console.print(f"[green]✅ Exported {len(logs)} logs to {filename}[/green]")
        
    except Exception as e:
        console.print(f"[red]❌ Export failed: {str(e)}[/red]")

if __name__ == '__main__':
    cli()