#!/usr/bin/env python3
"""
Interactive API Key Checker
连续输入密钥进行检查的交互式脚本
"""

import sys
from typing import Optional

from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.prompt import Prompt, Confirm
from rich import print as rprint

from api_client import NewAPIClient
from config import config
from cli import _display_results, _get_server_url

console = Console()

def main():
    """Main interactive loop"""
    console.print(Panel.fit(
        "🐱 Neko API Key Tool - 交互式密钥检查器\n\n"
        "输入密钥进行检查，输入 'quit' 或 'exit' 退出",
        title="🔍 Interactive Token Checker"
    ))
    
    # Get server configuration once
    server_url = _get_server_url(None)
    if not server_url:
        console.print("[red]❌ 未配置服务器，请先配置服务器[/red]")
        return
    
    # Create API client
    client = NewAPIClient(server_url)
    
    console.print(f"[green]✅ 使用服务器: {server_url}[/green]\n")
    
    # Interactive loop
    while True:
        try:
            # Get token input
            token = Prompt.ask(
                "[cyan]请输入API密钥[/cyan] (或输入 'quit'/'exit' 退出)",
                default=""
            ).strip()
            
            # Check for exit commands
            if token.lower() in ['quit', 'exit', 'q']:
                console.print("[yellow]👋 再见![/yellow]")
                break
            
            # Skip empty input
            if not token:
                console.print("[yellow]⚠️  密钥不能为空[/yellow]")
                continue
            
            # Validate token format
            if not client.validate_token_format(token):
                console.print("[red]❌ 无效的密钥格式。期望格式: sk-xxx, sess-xxx[/red]")
                continue
            
            # Query token information
            console.print()
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=console
            ) as progress:
                task = progress.add_task("🔍 正在查询密钥信息...", total=None)
                
                try:
                    result = client.get_complete_token_info(token)
                except Exception as e:
                    console.print(f"[red]❌ 查询失败: {str(e)}[/red]")
                    console.print()
                    continue
            
            # Display results
            _display_results(result, True, True)
            
            # Ask if user wants to continue
            console.print("─" * 60)
            
        except KeyboardInterrupt:
            console.print("\n[yellow]👋 程序被中断，再见![/yellow]")
            break
        except Exception as e:
            console.print(f"[red]❌ 发生错误: {str(e)}[/red]")
            continue

if __name__ == '__main__':
    main()